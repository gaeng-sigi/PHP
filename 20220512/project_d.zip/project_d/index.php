<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
    <link rel="stylesheet" href="css1.css">
</head>
<body>
    <header>
        <div class="header-box">
            <div class="nav">
                <ul>
                    <li><a href="#">Recipe</a></li>
                    <li><a href="#">QnA</a></li>
                </ul>
            </div>
            <div class="logo">
                <h1><a href="#">LOGO</a></h1>
            </div>
            <div class="join">
                <span><a href="#">로그인</a></span>
                <span><a href="#">회원가입</a></span>
            </div>
        </div>
    </header>
</body>
</html>